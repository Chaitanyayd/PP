package com.cg.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@SequenceGenerator(name="transactionId", initialValue=100, allocationSize=1 )
@Entity
public class Transaction {
	@Id
	@Column
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator= "transaction"
			+ "Id")
	private int transactionId;
	private List <String> transaction = new ArrayList<String>();

	public List <String> getTransaction() {
		return transaction;
	}

	public void setTransaction(List <String> transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Transaction [transaction=" + transaction + "]";
	}
	
	
	
}
